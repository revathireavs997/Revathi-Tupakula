
    

package com.charan.spring.hibernate.service;

import java.util.List;
 
import org.apache.log4j.Logger;

import org.springframework.orm.hibernate5.HibernateTemplate;

import com.charan.spring.hibernate.pojo.SmartShopProduct1;
import com.charan.spring.hibernate.pojo.User1;


 
public class AuthService {
 
    private HibernateTemplate hibernateTemplate;
    private static Logger log = Logger.getLogger(AuthService.class);
 
    private AuthService() { }
 
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate)
    
    {
        this.hibernateTemplate = hibernateTemplate;
    }
 
    @SuppressWarnings( { "unchecked", "deprecation" } )
    public boolean findUser(String uname, String upwd)
    
    {
    	
        log.info("Checking the user in the database");
        
        boolean isValidUser = false;
        
        //String sqlQuery = "from User where name='"+uname + "' and password='"+upwd+"'";
        
        
            
        //System.out.println("In the authentication service...user entered data " + uname + " pwd "+upwd);
        
        try {

  //String sqlQuery = "from User1";
        	String sqlQuery = "from User1 u where u.userid=? and u.password=?";        	
        	 
         	List<User1> userObj = (List<User1>) hibernateTemplate.find(sqlQuery, uname, upwd);
        	 
         	System.out.println("After select query from session..");
         	
            if(userObj != null)
            {
            	System.out.println("userObject is not null... ");
                for (User1 obj : userObj)
                {
                    System.out.println(" Name " + obj.getUserid() + " Password "+obj.getPassword() );
                            
                }

            }

        	
        	  
            if(userObj != null && userObj.size() > 0)
            {
                //log.info("Id= " + userObj.get(0)).getId() + ", Name= " + userObj.get(0).getName() + ", Password= " + userObj.get(0).getPassword());
                isValidUser = true;
            } 
        } catch(Exception e) {
            isValidUser = false;
            log.error("An error occurred while fetching the user details from the database", e); 
            System.out.println(e);
        }
        return isValidUser;
    }

    public boolean registerUser(User1 u)
    {
    	try
    	{    	
    	
    	System.out.println("Before Entering Data");
    	boolean isValidUser=true;

    	hibernateTemplate.save(u);
    	
    	
    	System.out.println("After Entering Data");
    	
    	return isValidUser;
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex);
    		ex.printStackTrace();
    		
    	}
		return false;
    }
    public List fetchProduct()
    {
    	log.info("Checking the user in the database");
    	 List<SmartShopProduct1> userObj=null;
        
         try {
        	 
         	
        	String sqlQuery = "from SmartShopProduct";        	
        	 
         	 userObj = (List<SmartShopProduct1>) hibernateTemplate.find(sqlQuery);
        	 
         	System.out.println("After select query from session..");
         	
            if(userObj != null)
            {
            	System.out.println("userObject is not null... ");
                for (SmartShopProduct1 obj : userObj)
                {
                  
                    return userObj;
                }

            }
        } 
         catch(Exception e) 
         {
         
            log.error("An error occurred while fetching the user details from the database", e); 
            System.out.println(e);
      
        }
         return userObj;
   
    
  

    }
}