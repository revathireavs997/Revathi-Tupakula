package com.charan.spring.hibernate.ctrl;
 



import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.charan.spring.hibernate.pojo.SmartShopProduct1;
import com.charan.spring.hibernate.service.AuthService;


 
@Component
@Controller

@RequestMapping("/user")
public class LoginCntrl {
 
    @Autowired
    private AuthService authenticateService;    
 
    // This will auto-inject the authentication service into the controller.
 
    
    private static Logger log = Logger.getLogger(LoginCntrl.class);
 
    // Checks if the user credentials are valid or not.
  
    
    @RequestMapping(value = "/validate", method = RequestMethod.POST)
    public ModelAndView validateUsr(@RequestParam("username")String username, @RequestParam("password")String password) 
    {
        String msg = "";
        
        boolean isValid = authenticateService.findUser(username, password);
     
        
        log.info("Is user valid?= " + isValid);
        
        System.out.println("In the controller..");
        
        if(isValid)
        {
        	      	
     		
    		//List<SmartShopProduct> lstProduct =  authenticateService.fetchProduct();
        	
        	SmartShopProduct1 smProduct = new SmartShopProduct1();
        	smProduct.setId(10);
        	smProduct.setProductRack("test");
 
        	List<SmartShopProduct1> lstProduct = new ArrayList<SmartShopProduct1>();
        	lstProduct.add(smProduct);
    		
            
            return new ModelAndView("result","productList",lstProduct);   
        }
        else
        {
            msg = "Invalid credentials";
           return new ModelAndView("index", "output", msg);
        }
           
       
    }
    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public ModelAndView logoutUsr()
    {
    	  String msg = "You have been Logout Successfully";
    	  return new ModelAndView("logout","output",msg);
    	
    }
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public ModelAndView loginUsr()
    {
    	  
    	  return new ModelAndView("index");
    	
    }   
}